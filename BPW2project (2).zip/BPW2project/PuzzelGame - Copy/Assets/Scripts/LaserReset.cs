using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserReset : MonoBehaviour
{
    public Receiver receiver;

    void OnParticleCollision(GameObject other)
    {
        receiver.laserHit = false;
    }
}
