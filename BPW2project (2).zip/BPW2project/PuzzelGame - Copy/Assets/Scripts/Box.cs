using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Box : MonoBehaviour
{
    public PlayerController playerController;
    public Transform box;
    public float moveDistance;
    public SpriteRenderer spriteRenderer;
    public Sprite opgepakt;
    public Sprite nietOpgepakt;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            spriteRenderer.sprite = opgepakt;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            spriteRenderer.sprite = nietOpgepakt;
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            if(playerController.moveDirection.x < 0)
            {
                box.position = new Vector2(box.position.x - moveDistance, box.position.y);
            }
            if(playerController.moveDirection.x > 0)
            {
                box.position = new Vector2(box.position.x + moveDistance, box.position.y);
            }
            if(playerController.moveDirection.y < 0)
            {
                box.position = new Vector2(box.position.x, box.position.y - moveDistance);
            }
            if(playerController.moveDirection.y > 0)
            {
                box.position = new Vector2(box.position.x, box.position.y + moveDistance);
            }
        }
    }
}
