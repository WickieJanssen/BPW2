using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Receiver : MonoBehaviour
{
    public bool laserHit;
    public SpriteRenderer spriteRenderer;
    public Sprite hitSprite;
    public Sprite sprite;

    private void Update()
    {
        if (laserHit)
        {
            spriteRenderer.sprite = hitSprite;
        }
        else
        {
            spriteRenderer.sprite = sprite;
        }
    }

    private void OnParticleCollision(GameObject other)
    {
        laserHit = true;
    }
}
