using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateLaser : MonoBehaviour
{
    public Transform laser;
    public SpriteRenderer spriteRenderer;
    public Sprite ingedrukt;
    public Sprite nietIngedrukt;
    public float rotation;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            spriteRenderer.sprite = ingedrukt;
            laser.Rotate(0,0, rotation);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            spriteRenderer.sprite = nietIngedrukt;
        }
    }
}
