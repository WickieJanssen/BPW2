using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Rigidbody2D rb;
    public float moveSpeed = 5.0f;
    public Vector2 moveDirection;
    public Animator animator;

    void ProcessInputs()
    {
        float moveY = Input.GetAxisRaw("Vertical");
        float moveX = Input.GetAxisRaw("Horizontal");
        moveDirection = new Vector2(moveX, moveY).normalized;
    }

    void move()
    {
        rb.velocity = new Vector2(moveDirection.x * moveSpeed, moveDirection.y * moveSpeed);
    }

    private void Update()
    {
        ProcessInputs();
        if(moveDirection.x != 0 || moveDirection.y != 0)
        {
            animator.enabled = true;
        }
        else
        {
            animator.enabled = false;
        }
    }

    void FixedUpdate()
    {
        move();
    }

    private void OnParticleCollision(GameObject other)
    {
        transform.position = new Vector2(0, -6.5f);
    }
}
