using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LopenOpWater : MonoBehaviour
{
    [SerializeField] private BoxCollider2D[] water;
    public SpriteRenderer spriteRenderer;
    public Sprite ingedrukt;
    public Sprite nietIngedrukt;
    [SerializeField] private SpriteRenderer[] spriteRendererWater;
    public Sprite waterSprite;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            for (int i = 0; i < water.Length; i++)
            {
                water[i].isTrigger = true;
            }
            for (int i = 0; i < spriteRendererWater.Length; i++)
            {
                spriteRendererWater[i].sprite = waterSprite;
            }
            spriteRenderer.sprite = ingedrukt;           
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            Destroy(gameObject);
        }
    }
}
