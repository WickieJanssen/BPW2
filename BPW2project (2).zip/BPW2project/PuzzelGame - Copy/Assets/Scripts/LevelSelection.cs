﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelSelection : MonoBehaviour
{
    public Button[] lvlButtons;

    // Start is called before the first frame update
    void Start()
    {
        int levelAt = PlayerPrefs.GetInt("levelAt", 2); 

        for (int i = 0; i < lvlButtons.Length; i++)
        {
            if (i + 2 > levelAt)
                lvlButtons[i].interactable = false;
        }
    }

    public void level1()
    {
        SceneManager.LoadScene("Level7");
    }
    public void level2()
    {
        SceneManager.LoadScene("Level13");
    }
    public void level3()
    {
        SceneManager.LoadScene("Level5.0");
    }
    public void level4()
    {
        SceneManager.LoadScene("Level11");
    }
    public void level5()
    {
        SceneManager.LoadScene("Level12");
    }
    public void level6()
    {
        SceneManager.LoadScene("Level8");
    }
    public void level7()
    {
        SceneManager.LoadScene("Level9");
    }
    public void level8()
    {
        SceneManager.LoadScene("Level10");
    }
}
