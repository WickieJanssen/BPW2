using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Tutorial : MonoBehaviour
{
    private int click;
    public Canvas canvas;
    void Update()
    {
        if (Input.GetKey(KeyCode.E))
        {
            click++;
            canvas.GetComponent<Canvas>().enabled = true;

            if (click > 1)
            {
                SceneManager.LoadScene("LevelSelection");
            }
        }
    }
}
